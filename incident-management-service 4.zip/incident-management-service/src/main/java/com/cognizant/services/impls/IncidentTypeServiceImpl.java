package com.cognizant.services.impls;

import com.cognizant.dtos.IncidentTypeDTO;
import com.cognizant.entities.IncidentTypes;
import com.cognizant.repositories.IncidentTypeRepository;
import com.cognizant.services.IncidentTypeService;
import com.cognizant.utilities.IncidentTypeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IncidentTypeServiceImpl implements IncidentTypeService {
    private final IncidentTypeRepository incidentTypeRepository;
    private  final IncidentTypeMapper incidentTypeMapper;
    @Autowired
    public IncidentTypeServiceImpl(IncidentTypeRepository incidentTypeRepository,IncidentTypeMapper incidentTypeMapper){
        this.incidentTypeRepository=incidentTypeRepository;
        this.incidentTypeMapper=incidentTypeMapper;
    }

    /**
     *
     * @return
     */
    @Override
    public List<IncidentTypeDTO> getAllIncidentTypes() {
        //using find all method we are finding all incident types that are present in the system
        List<IncidentTypes> incidentTypesList = incidentTypeRepository.findAll();

        //we are converting incident type entity to incident type dto
        //using map method, then we are converting it into list
        return incidentTypesList.stream()
                .map(incidentTypeMapper::toIncidentTypeDTO)
                .toList();
    }
}
