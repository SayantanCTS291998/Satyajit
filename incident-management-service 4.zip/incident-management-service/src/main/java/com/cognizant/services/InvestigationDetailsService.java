package com.cognizant.services;

import com.cognizant.dtos.InvestigationReportDTO;

import java.util.List;

public interface InvestigationDetailsService {
    InvestigationReportDTO createInvestigationReport(InvestigationReportDTO investigationReportDTO);

    List<InvestigationReportDTO> getAllInvestigationReport();
}
