package com.cognizant.exceptions;

public class IdFoundException extends RuntimeException{
    public IdFoundException(String message){
        super(message);
    }
}
