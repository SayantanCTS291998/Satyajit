import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DriveComponent } from './drive/drive.component';
import { HelpDeskComponent } from './help-desk/help-desk.component';
import { IncidentListComponent } from './help-desk/incident-list/incident-list.component';
import { TrackIncidentComponent } from './help-desk/track-incident/track-incident.component';
import { NewIncidentComponent } from './help-desk/new-incident/new-incident.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { RideComponent } from './ride/ride.component';
import { UpdateIncidentComponent } from './help-desk/update-incident/update-incident.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { SignupComponent } from './signup/signup.component';
import { LoginGaurdService } from './guards/login-guard.guard';
import { AuthGaurdUserService } from './guards/auth-user.guard';
import { AuthGaurdAdminService } from './guards/auth-admin.guard';
import { AboutComponent } from './about/about.component';
const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'drive', component: DriveComponent, canActivate: [LoginGaurdService] },
  { path: 'ride', component: RideComponent, canActivate: [LoginGaurdService] },
  { path: 'about', component: AboutComponent },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'help', component: HelpDeskComponent, canActivate: [LoginGaurdService] },
  { path: 'help/report', component: NewIncidentComponent, canActivate: [LoginGaurdService, AuthGaurdUserService] },
  { path: 'help/find', component: TrackIncidentComponent, canActivate: [LoginGaurdService] },
  { path: 'help/find/:id', component: TrackIncidentComponent, canActivate: [LoginGaurdService] },
  { path: 'help/pending/incidents', component: IncidentListComponent, canActivate: [LoginGaurdService, AuthGaurdAdminService] },
  { path: 'help/update', component: UpdateIncidentComponent, canActivate: [LoginGaurdService, AuthGaurdAdminService] },
  { path: 'help/update/:id', component: UpdateIncidentComponent, canActivate: [LoginGaurdService, AuthGaurdAdminService] },
  { path: '', redirectTo: "/home", pathMatch: 'full' },
  { path: '**', component: NotfoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
