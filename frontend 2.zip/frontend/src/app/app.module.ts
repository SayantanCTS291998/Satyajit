import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HelpDeskComponent } from './help-desk/help-desk.component';
import { HomeComponent } from './home/home.component';
import { DriveComponent } from './drive/drive.component';
import { RideComponent } from './ride/ride.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NewIncidentComponent } from './help-desk/new-incident/new-incident.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IncidentListComponent } from './help-desk/incident-list/incident-list.component';
import { TrackIncidentComponent } from './help-desk/track-incident/track-incident.component';
import { HttpClientModule } from '@angular/common/http';
import { UpdateIncidentComponent } from './help-desk/update-incident/update-incident.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { NotfoundComponent } from './notfound/notfound.component';
import { SignupComponent } from './signup/signup.component';
import { AboutComponent } from './about/about.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HelpDeskComponent,
    HomeComponent,
    DriveComponent,
    RideComponent,
    LoginComponent,
    LogoutComponent,
    NewIncidentComponent,
    IncidentListComponent,
    TrackIncidentComponent,
    UpdateIncidentComponent,
    NotfoundComponent,
    SignupComponent,
    AboutComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
