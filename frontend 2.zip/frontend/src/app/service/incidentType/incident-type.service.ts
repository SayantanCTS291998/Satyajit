import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IncidentType } from '../../model/IncidentType';

@Injectable({
    providedIn: 'root'
})
export class IncidentTypeService {

    private baseUrl: string = 'http://localhost:8089/api';
    constructor(private http: HttpClient) { }

    getAllIncidentType() {
        const incidentTypeUrl = `${this.baseUrl}/incidents/types`;
        return this.http.get<IncidentType[]>(incidentTypeUrl);
    }
}
