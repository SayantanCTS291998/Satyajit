import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Incident } from '../../model/Incident';
import { InvestigationReport } from '../../model/InvestigationDetails';

@Injectable({
    providedIn: 'root'
})
export class IncidentService {

    private baseUrl = 'http://localhost:8089/api';

    constructor(private http: HttpClient) { }

    createNewIncident(incident: Incident) {
        const createIncidentUrl = `${this.baseUrl}/incidents/report`;
        return this.http.post<Incident>(createIncidentUrl, incident);
    }

    findAllPendingIncidents() {
        const pendingIncidentUrl = `${this.baseUrl}/incidents`;
        return this.http.get<Incident[]>(pendingIncidentUrl);
    }

    findIncidentById(incidentId: string) {
        const findByIdUrl = `${this.baseUrl}/incidents/${incidentId}`;
        return this.http.get<Incident>(findByIdUrl);
    }

    updateAnIncident(incidentId: string, investigationReport: InvestigationReport) {
        const updateAnIncidentUrl = `${this.baseUrl}/incidents/${incidentId}/investigationreport`;
        return this.http.put<InvestigationReport>(updateAnIncidentUrl, investigationReport);
    }

    findInvestigationReport() {
        const investigationUrl = `${this.baseUrl}/incidents/investigation`;
        return this.http.get<InvestigationReport[]>(investigationUrl);
    }
}
