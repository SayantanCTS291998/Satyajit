import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { User } from '../model/User';
import { first } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AuthenticationService implements OnInit {

    user: User;

    authenticated: boolean = false;

    users: User[];

    userBackend: User;

    isUser: boolean = false;
    isAdmin: boolean = false;

    constructor(private http: HttpClient) { }

    ngOnInit(): void {
    }

    isAuthenticated(username: string, password: string) {


        this.user = new User();
        this.user.userName = username;
        this.user.password = password;

        this.http.post<User>('http://localhost:8089/api/authenticate/users', this.user).pipe(first())
            .subscribe({
                next: (data) => {


                    this.userBackend = new User();
                    this.userBackend.userName = data.userName;
                    this.userBackend.password = data.password;
                    this.userBackend.role = data.role;
                    this.user.role = data.role;
                    console.log(data.role);

                    if (data.role === 'admin') {
                        this.isAdmin = true;
                    }
                    if (data.role === 'user') {
                        this.isUser = true;
                    }
                    if (this.user.userName === this.userBackend.userName && this.user.password === this.userBackend.password) {
                        this.authenticated = true;
                        sessionStorage.setItem('username', username);
                        console.log("what is role? " + this.userBackend.role);
                        console.log("what is role? " + this.userBackend.userName);
                        sessionStorage.setItem('role', this.userBackend.role);
                    } else {
                        this.authenticated = false;
                    }


                }

            });


        return this.authenticated;

    }

    // getUser(user: User) {
    //     return this.http.post<User>('http://localhost:8089/api/authenticate/users', user);
    // }

    isUserLoggedIn() {
        let user = sessionStorage.getItem('username');
        let role = sessionStorage.getItem('role');

        return !(user === null && role === null);
    }

    isUserAdmin() {
        let role = sessionStorage.getItem('role');
        return role === 'admin';
    }

    isUserNotAdmin() {
        let role = sessionStorage.getItem('role');
        return role === 'user';
    }
    logOut() {
        sessionStorage.removeItem('username');
        sessionStorage.removeItem('role');
    }
}
