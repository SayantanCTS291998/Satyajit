import { Component, OnInit } from '@angular/core';
import { Incident } from 'src/app/model/Incident';
import { IncidentService } from 'src/app/service/incidents/incident.service';

@Component({
    selector: 'app-incident-list',
    templateUrl: './incident-list.component.html',
    styleUrls: ['./incident-list.component.css']
})
export class IncidentListComponent implements OnInit {

    showOnlyWhenClicked: boolean = false;

    isPendingListEmpty: boolean = true;

    pendingIncidents: Incident[] = [];

    incident: Incident;

    page: number = 1;

    errorStatus: number;

    constructor(private incidentService: IncidentService) { }

    ngOnInit(): void {
    }

    onClick() {
        this.incidentService.findAllPendingIncidents()
            .subscribe({
                next: (response) => { this.pendingIncidents = response },
                error: (error) => {
                    console.log(error.status);
                    this.errorStatus = error.status;
                }
            });
        this.isPendingListEmpty = this.pendingIncidents.length === 0 ? true : false;
        this.showOnlyWhenClicked = true;
    }


    sortDirection: string = '';

    sortTable(column: string) {
        this.sortDirection = 'asc';
        this.pendingIncidents.sort((a, b) => {
            if (column === 'incidentDate') {
                const dateA = new Date(a[column]).getDate();
                const dateB = new Date(b[column]).getDate();
                return this.sortDirection === 'asc' ? dateA - dateB : dateB - dateA;
            } else {
                return this.sortDirection === 'asc' ? a[column] - b[column] : b[column] - a[column];
            }
        })
    }

}
