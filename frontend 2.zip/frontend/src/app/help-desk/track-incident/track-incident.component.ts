import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Incident } from 'src/app/model/Incident';
import { InvestigationReport } from 'src/app/model/InvestigationDetails';
import { IncidentService } from 'src/app/service/incidents/incident.service';


@Component({
    selector: 'app-track-incident',
    templateUrl: './track-incident.component.html',
    styleUrls: ['./track-incident.component.css']
})
export class TrackIncidentComponent implements OnInit {

    incidentId: string | undefined;

    clickedOrNot: boolean = false;

    incidentStatus: string = '';

    errorStatus: number;

    incidentDetails: Incident = {
        incidentId: null,
        incidentDate: null,
        reportDate: null,
        incidentReportedByUserId: null,
        resolutionETA: null,
        investigatedByUserId: null,
        incidentSummary: null,
        incidentDetails: null,
        bookingId: null,
        status: null,
        incidentTypeId: null
    };


    investigationReport: InvestigationReport[] = [];
    investigationReportList: InvestigationReport[] = [];
    searchForm: FormGroup;

    constructor(private route: ActivatedRoute, private incidentService: IncidentService,
        private formBuilder: FormBuilder,
    ) { }

    ngOnInit(): void {

        this.route.params.subscribe(params => {

            if (params['id'] !== undefined) {
                this.incidentId = params['id'];
            }


        });

        this.searchForm = this.formBuilder.group({
            incidentId: [this.incidentId, [Validators.required, Validators.pattern(/^\d{4}-\d{4}$/)]],
        })

    }

    onSubmit() {
        this.incidentService.findIncidentById(this.searchForm.get('incidentId').value)
            .subscribe({
                next: (response) => {
                    this.incidentDetails = response;
                    this.incidentStatus = this.incidentDetails.status;
                    console.log(this.incidentDetails);

                },
                error: (error) => {
                    this.errorStatus = error.status;
                }
            });

        this.incidentService.findInvestigationReport().subscribe(
            {
                next: (response) => {

                    this.investigationReport = response;
                    this.investigationReport.forEach(element => {

                        if (element.incidentId === this.searchForm.get('incidentId').value) {
                            console.log(element);

                            this.investigationReportList.push(element);
                        }
                    });
                    console.log(this.investigationReportList);

                },
                error: (error) => {
                    console.log(error.error);

                }
            }
        )
        console.log(this.investigationReport);
        this.searchForm.reset();
    }

    onClick() {
        this.clickedOrNot = true;
    }

    isResolved(): boolean {
        if (this.incidentStatus === 'CLOSED') {
            return true;
        }
        return false;
    }
}
