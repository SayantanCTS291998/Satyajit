import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { InvestigationReport } from 'src/app/model/InvestigationDetails';
import { IncidentService } from 'src/app/service/incidents/incident.service';


@Component({
    selector: 'app-update-incident',
    templateUrl: './update-incident.component.html',
    styleUrls: ['./update-incident.component.css']
})
export class UpdateIncidentComponent implements OnInit {

    incidentId: string;
    currentDate: Date;

    investigation: InvestigationReport = {
        investigationDetailsId: null,
        findings: null,
        suggestions: null,
        investigationDate: null,
        incidentId: null,
    };

    investigationForm: FormGroup;

    isSubmitted: boolean = false;
    isFilled: boolean = false;

    constructor(private incidentService: IncidentService,
        private route: ActivatedRoute,
        private formBuilder: FormBuilder,
    ) {
        this.currentDate = new Date();
        this.currentDate.setHours(0, 0, 0, 0);

    }


    ngOnInit(): void {

        this.route.params.subscribe(params => {
            this.incidentId = params['id'];
        });

        this.investigationForm = this.formBuilder.group({
            findings: ['', [Validators.required, Validators.pattern(/^[a-zA-Z\s]*$/),
            Validators.minLength(10), Validators.maxLength(500)]],
            suggestions: ['', [Validators.required, Validators.pattern(/^[a-zA-Z\s]*$/), Validators.minLength(10), Validators.maxLength(500)]],
            investigationDate: ['', [Validators.required, currentDateValidator()]],
            incidentId: [this.incidentId, [Validators.required, Validators.pattern(/^\d{4}-\d{4}$/)]],
        })

    }

    handleChangeStatus() {
        this.isSubmitted = true;
    }
    onSubmit() {

        this.incidentService.updateAnIncident(this.investigationForm.get('incidentId').value,
            this.investigationForm.value).subscribe((response) => {
                this.investigation = response;
                console.log(this.investigation);
            })
    }


}


function currentDateValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
        const selectedDate = new Date(control.value);
        const currDate = new Date();
        currDate.setHours(0, 0, 0, 0);
        if (selectedDate.toDateString() !== currDate.toDateString()) {
            return { invalidCurrentDate: true };
        }

        return null;
    };
}