import { Component } from '@angular/core';
import { AuthenticationService } from '../service/authentication.service';

@Component({
    selector: 'app-help-desk',
    templateUrl: './help-desk.component.html',
    styleUrls: ['./help-desk.component.css']
})
export class HelpDeskComponent {

    constructor(public authenticationService: AuthenticationService) { }
}
