import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControlName, FormGroup, ValidationErrors, Validator, ValidatorFn, Validators } from '@angular/forms';
import { catchError, throwError } from 'rxjs';
import { IncidentTypeDto } from 'src/app/model/IncidentTypeDto';
import { Incident } from 'src/app/model/Incident';
import { IncidentService } from 'src/app/service/incidents/incident.service';

import { IncidentTypeService } from 'src/app/service/incidentType/incident-type.service';
import { IncidentType } from 'src/app/model/IncidentType';

@Component({
    selector: 'app-new-incident',
    templateUrl: './new-incident.component.html',
    styleUrls: ['./new-incident.component.css']
})
export class NewIncidentComponent implements OnInit {

    incidentTypeList: IncidentType[] = [];

    isSubmitted: boolean = false;

    httpStatus: number;
    incidentForm: FormGroup;

    incidentId: string;

    createdIncident: Incident;

    currentDate: Date;

    incidentTypeDto: IncidentTypeDto[] = [];

    constructor(private incidentTypeService: IncidentTypeService,
        private incidentService: IncidentService,
        private formBuilder: FormBuilder,

    ) {

        this.currentDate = new Date();
        this.currentDate.setHours(0, 0, 0, 0);
    }

    ngOnInit(): void {
        this.incidentTypeService.getAllIncidentType()
            .subscribe({
                next: response => {
                    this.incidentTypeList = response
                    this.incidentTypeList.forEach(element => {
                        switch (element.type) {
                            case 1: {
                                this.incidentTypeDto.push(new IncidentTypeDto(element.incidentTypeId, "Accident", element.expectedSLAInDays));
                                break;
                            }
                            case 2: {
                                this.incidentTypeDto.push(new IncidentTypeDto(element.incidentTypeId, "Customer Dispute", element.expectedSLAInDays));
                                break;
                            }
                            case 3: {
                                this.incidentTypeDto.push(new IncidentTypeDto(element.incidentTypeId, "Lost Item", element.expectedSLAInDays));
                                break;
                            }
                            case 4: {
                                this.incidentTypeDto.push(new IncidentTypeDto(element.incidentTypeId, "Medical Emergency", element.expectedSLAInDays));
                                break;
                            }
                            default: {
                                break;
                            }
                        }

                    });
                    console.log(this.incidentTypeDto);

                },
                error: (error) => {
                    console.log(error.message)
                }
            });

        this.incidentForm = this.formBuilder.group({
            incidentTypeId: ['', Validators.required],
            incidentDate: ['', [Validators.required, incidentDateValidator()]],
            reportDate: ['', [Validators.required, currentDateValidator()]],
            incidentDetails: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(500), Validators.pattern(/^[a-zA-Z\s]*$/)]]
        });
    }
    onSubmit() {
        this.incidentService.createNewIncident(this.incidentForm.value)
            .subscribe({
                next: (response) => {
                    this.incidentId = response.incidentId;
                    this.createdIncident = response;
                    console.log(response);

                },
                error: (error) => {
                    console.log(error);

                }
            });
        console.log(this.incidentForm);

    }




    handleChangeStatus() {
        this.isSubmitted = true;
    }
}


function currentDateValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
        const selectedDate = new Date(control.value);
        const currDate = new Date();
        currDate.setHours(0, 0, 0, 0);
        if (selectedDate.toDateString() !== currDate.toDateString()) {
            return { invalidCurrentDate: true };
        }

        return null;
    };
}
function incidentDateValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
        const selectedDate = new Date(control.value);
        const currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);

        const maxValidDate = new Date(currentDate);
        maxValidDate.setDate(maxValidDate.getDate() - 2);
        maxValidDate.setHours(0, 0, 0, 0);


        const selectedDateUTC = new Date(selectedDate.toUTCString());
        const currentDateUTC = new Date(currentDate.toUTCString());
        const maxDateUTC = new Date(maxValidDate.toUTCString());

        console.log(selectedDateUTC.getDate(), currentDateUTC.getDate(), maxDateUTC.getDate(),);


        if (!(selectedDateUTC.getDate() >= maxDateUTC.getDate() && selectedDateUTC.getDate() <= currentDateUTC.getDate())) {
            return { invalidIncidentDate: true };
        }

        return null;
    };
}