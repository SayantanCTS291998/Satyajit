export class Incident {
    public incidentId?: string;
    public incidentDate: Date;
    public reportDate: Date;
    public incidentReportedByUserId?: number;
    public resolutionETA?: Date;
    public investigatedByUserId?: number;
    public incidentSummary?: string;
    public incidentDetails: string;
    public bookingId?: number;
    public status?: string;
    public incidentTypeId: number;
}