export class InvestigationReport {
    public investigationDetailsId?: number;
    public findings: string;
    public suggestions: string;
    public investigationDate: Date;
    public incidentId: string;
}