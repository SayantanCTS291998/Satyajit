
export class IncidentType {
    public incidentTypeId: number;
    public type: number;
    public expectedSLAInDays: number;
}