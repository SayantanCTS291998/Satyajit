export class IncidentTypeDto {
    constructor(
        public incidentTypeId?: number,
        public type?: string,
        public expectedSLAInDays?: number,
    ) { }
}