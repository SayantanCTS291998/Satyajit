import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    invalidLogin: boolean = false;

    constructor(
        private loginFromBuilder: FormBuilder,
        private router: Router,
        private loginService: AuthenticationService
    ) { }

    ngOnInit(): void {
        this.loginForm = this.loginFromBuilder.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });

        // this.checkLogin();
    }


    onSubmit() {
        console.log(this.loginForm.value);
        this.checkLogin();
    }

    checkLogin() {

        if (this.loginService.isAuthenticated(this.loginForm.get('username').value, this.loginForm.get('password').value)) {
            this.router.navigateByUrl('');
            console.log(this.loginService.isUserAdmin());
            console.log(this.loginService.isUserNotAdmin());

        } else {
            this.router.navigateByUrl("/login");
        }

    }

    onClick() {
        this.router.navigate(['/signup']);
    }
}
