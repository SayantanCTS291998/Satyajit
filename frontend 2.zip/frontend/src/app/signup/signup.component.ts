import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, ValidatorFn } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
    signupForm: FormGroup;

    constructor(private signupFormBuilder: FormBuilder,
        private router: Router) { }

    ngOnInit(): void {
        this.signupForm = this.signupFormBuilder.group({
            username: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            password: ['', Validators.required],
            confirmPassword: ['', [Validators.required]]
        })
    }

    onSubmit() {
        console.log(this.signupForm.value);
        localStorage.setItem("username", this.signupForm.value.username);
        this.router.navigate(['/home']);
    }

}
